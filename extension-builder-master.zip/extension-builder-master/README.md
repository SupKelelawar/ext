# Extension Builder
An easy way to compile [ani/tachi]yomi extensions when you're far from a proper setup (or when you dont have one), using github actions.

## Usage

 1. Fork the repo
 2. Enable ACTIONS on the fork
 3. Go to actions page and select `Build single extension` workflow
 4. Fill the required/wanted spaces and run it
 5. Wait the compilation and get the APK from the artifacts of the action.

## TODO

 - [x] Add multisrc support
